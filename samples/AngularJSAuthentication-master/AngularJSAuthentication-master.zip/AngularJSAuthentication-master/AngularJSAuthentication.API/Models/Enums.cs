﻿namespace AngularJSAuthentication.API.Models
{
    public enum ApplicationTypes
    {
        JavaScript = 0,
        NativeConfidential = 1
    }
}