﻿namespace AngularJSAuthentication.API.Entities
{
    using AspNet.Identity.MongoDB;

    public class Role : IdentityRole
    {
    }
}
